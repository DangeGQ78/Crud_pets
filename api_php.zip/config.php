<?php

session_start();
$host = "localhost"; /* equipo */
$user = "id20606546_admin"; /* usuario */
$password = "z4N]!Cjg]5DC[pXZ"; /* clave */
$dbname = "id20606546_maestros"; /* base de datos */

$con = mysqli_connect($host, $user, $password,$dbname);

if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
//echo "Conexion Exitosa";

?>

