<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: HEAD, GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method,Access-Control-Request-Headers, Authorization");
header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];
if ($method == "OPTIONS") {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method,Access-Control-Request-Headers, Authorization");
    header("HTTP/1.1 200 OK");
    die();
}

require "config.php";

if (isset($_POST['foto']) && isset($_POST['nombre']) && isset($_POST['raza']) && isset($_POST['estado']) && isset($_POST['iduser'])) {
    $foto = $_POST['foto'];
    $nombre = $_POST['nombre'];
    $raza = $_POST['raza'];
    $estado = $_POST['estado'];
    $iduser = $_POST['iduser'];
    
    // Convertir el estado y el iduser a números enteros
    $estado = intval($estado);
    $iduser = intval($iduser);
    
    $sql = "INSERT INTO pets (foto, nombre, raza, estado, iduser) VALUES ('$foto', '$nombre', '$raza', $estado, $iduser)";
$res = mysqli_query($con, $sql);
    if ($res) {
        $response[] = array('mensaje' => "Mascota almacenada en la base de datos");
    } else {
        $response[]= array('mensaje' => "Error al almacenar la mascota en la base de datos");
    }
} else {
    $response[] = array('mensaje' => "Faltan datos para almacenar la mascota en la base de datos:");
}

$json_string = json_encode($response);
echo $json_string;
?>

