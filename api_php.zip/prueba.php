<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: HEAD, GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method,Access-Control-Request-Headers, Authorization");
header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];
if ($method == "OPTIONS") {
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method,Access-Control-Request-Headers, Authorization");
header("HTTP/1.1 200 OK");
die();
}


    require "config.php";
    
     if( isset($_POST['id']) and isset($_POST['foto']) and isset($_POST['nombre']) and isset($_POST['raza']) and isset($_POST['estado']) and isset($_POST['iduser']) ) {
         
    $idMascota = intval($_POST['id']); // Obtener el ID de la mascota a actualizar
    $idFoto = $_POST['foto']; // Obtener el ID de la foto de la mascota
    $nuevoNombre = $_POST['nombre']; // Obtener el nuevo nombre de la mascota
    $nuevaRaza = $_POST['raza']; // Obtener la nueva raza de la mascota
    $nuevoEstado = intval($_POST['estado']); // Obtener el nuevo estado de la mascota
    $idUsuario = intval($_POST['iduser']); // Obtener el ID del usuario dueño de la mascota

    $sql = "UPDATE pets SET foto = '$idFoto', nombre = '$nuevoNombre', raza = '$nuevaRaza' WHERE id = '$idMascota'"; // Cambiar la consulta para actualizar los campos de la mascota por su ID
    
  $res = mysqli_query($con, $sql);
 
    if ($res) {
         $clientes[] = array('mensaje'=> "pet actualizada");
  } else {
       $clientes[] = array('mensaje'=> "pet no actualizada");
  }
     }else{
          $clientes[] = array('mensaje'=> "pet no actualizada2");
     }
     

    
   
$json_string = json_encode($clientes);
echo $json_string;
?>
